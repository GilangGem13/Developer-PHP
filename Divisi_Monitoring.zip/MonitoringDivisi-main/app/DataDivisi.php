<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataDivisi extends Model
{
    protected $table = 'datadivisi';
    protected $fillable = ['id','datadivisi'];
}
