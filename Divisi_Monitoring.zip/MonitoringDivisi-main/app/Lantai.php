<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lantai extends Model
{
    protected $table = 'Lantai';
    protected $fillable = ['id','lantai'];
}
