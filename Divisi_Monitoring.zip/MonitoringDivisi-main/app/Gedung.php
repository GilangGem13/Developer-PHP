<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gedung extends Model
{
    protected $table = 'Gedung';
    protected $fillable = ['id','gedung'];
}
